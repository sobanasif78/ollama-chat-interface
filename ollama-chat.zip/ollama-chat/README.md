# 🧠 Ollama Chat — Local LLM Interface

A sleek, dark-themed Streamlit interface for chatting with any model running via Ollama.

---

## Prerequisites

| Tool | Install |
|------|---------|
| Python 3.9+ | https://python.org |
| Ollama | https://ollama.com |

---

## Setup (3 steps)

### 1 · Install Ollama & pull a model
```bash
# Install Ollama (macOS/Linux)
curl -fsSL https://ollama.com/install.sh | sh

# Pull a model (choose one)
ollama pull llama3        # Meta Llama 3 8B  (~4.7 GB)
ollama pull mistral       # Mistral 7B       (~4.1 GB)
ollama pull phi3          # Microsoft Phi-3  (~2.3 GB)
ollama pull gemma2        # Google Gemma 2   (~5.4 GB)

# Start the server (if not already running)
ollama serve
```

### 2 · Install Python dependencies
```bash
pip install -r requirements.txt
```

### 3 · Run the app
```bash
streamlit run app.py
```

Then open **http://localhost:8501** in your browser.

---

## Features

- **Live streaming** responses token-by-token
- **Multi-conversation** management with sidebar history
- **Adjustable parameters** — temperature, max tokens
- **Custom system prompts** per session
- **Auto model discovery** — lists all locally pulled models
- **Connection status** indicator
- **Reset button** to clear the active chat

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `OFFLINE` badge | Run `ollama serve` in a terminal |
| No models listed | Run `ollama pull <model>` first |
| Slow responses | Use a smaller model (phi3, gemma2:2b) |
| Port conflict | Change port: `OLLAMA_HOST=0.0.0.0:11435 ollama serve` and update `OLLAMA_BASE` in `app.py` |
