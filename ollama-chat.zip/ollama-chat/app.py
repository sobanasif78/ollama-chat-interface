import streamlit as st
import requests
import json
import time
from datetime import datetime

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Ollama Chat",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:ital,wght@0,400;0,700;1,400&family=Syne:wght@400;600;800&display=swap');

/* Global reset */
*, *::before, *::after { box-sizing: border-box; }

html, body, [data-testid="stAppViewContainer"] {
    background-color: #0a0a0f !important;
    color: #e8e6f0 !important;
    font-family: 'Syne', sans-serif;
}

[data-testid="stSidebar"] {
    background: #0f0f1a !important;
    border-right: 1px solid #1e1e3a !important;
}

[data-testid="stSidebar"] * { color: #e8e6f0 !important; }

/* Header */
.app-header {
    text-align: center;
    padding: 2rem 0 1.5rem;
    border-bottom: 1px solid #1e1e3a;
    margin-bottom: 2rem;
}
.app-header h1 {
    font-family: 'Syne', sans-serif;
    font-weight: 800;
    font-size: 2.6rem;
    letter-spacing: -0.03em;
    background: linear-gradient(135deg, #a78bfa 0%, #60a5fa 50%, #34d399 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin: 0;
}
.app-header p {
    font-family: 'Space Mono', monospace;
    font-size: 0.78rem;
    color: #555577;
    margin: 0.4rem 0 0;
    letter-spacing: 0.08em;
    text-transform: uppercase;
}

/* Status badge */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 12px;
    border-radius: 20px;
    font-family: 'Space Mono', monospace;
    font-size: 0.72rem;
    letter-spacing: 0.05em;
    margin-bottom: 1.2rem;
}
.status-online  { background: #0d2b1e; border: 1px solid #34d399; color: #34d399; }
.status-offline { background: #2b0d0d; border: 1px solid #f87171; color: #f87171; }

/* Chat messages */
.chat-container {
    display: flex;
    flex-direction: column;
    gap: 1.2rem;
    padding: 1rem 0;
}
.message-row { display: flex; align-items: flex-start; gap: 0.8rem; }
.message-row.user  { flex-direction: row-reverse; }
.avatar {
    width: 36px; height: 36px; border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1rem; flex-shrink: 0; margin-top: 2px;
}
.avatar-user { background: linear-gradient(135deg, #a78bfa, #60a5fa); }
.avatar-ai   { background: linear-gradient(135deg, #1e1e3a, #2d2d5a); border: 1px solid #3d3d7a; }
.bubble {
    max-width: 78%;
    padding: 0.9rem 1.1rem;
    border-radius: 14px;
    line-height: 1.65;
    font-size: 0.93rem;
}
.bubble-user {
    background: linear-gradient(135deg, #2d1f5e, #1f2d5e);
    border: 1px solid #4a3a8a;
    color: #ddd8ff;
    border-top-right-radius: 4px;
}
.bubble-ai {
    background: #12121f;
    border: 1px solid #1e1e3a;
    color: #d4d0e8;
    border-top-left-radius: 4px;
}
.bubble pre {
    background: #0a0a14;
    border: 1px solid #1e1e3a;
    border-radius: 8px;
    padding: 0.8rem;
    overflow-x: auto;
    font-family: 'Space Mono', monospace;
    font-size: 0.8rem;
    margin: 0.5rem 0;
}
.bubble code {
    font-family: 'Space Mono', monospace;
    font-size: 0.82em;
    background: #1a1a2e;
    padding: 1px 5px;
    border-radius: 4px;
    color: #a78bfa;
}
.msg-time {
    font-family: 'Space Mono', monospace;
    font-size: 0.64rem;
    color: #444466;
    margin-top: 4px;
    padding: 0 4px;
}
.msg-time.right { text-align: right; }

/* Thinking indicator */
.thinking {
    display: flex; align-items: center; gap: 8px;
    padding: 0.7rem 1rem;
    background: #12121f;
    border: 1px solid #1e1e3a;
    border-radius: 12px;
    border-top-left-radius: 4px;
    font-family: 'Space Mono', monospace;
    font-size: 0.75rem;
    color: #6666aa;
    width: fit-content;
}
.dot {
    width: 6px; height: 6px; border-radius: 50%;
    background: #a78bfa;
    animation: pulse 1.4s ease-in-out infinite;
}
.dot:nth-child(2) { animation-delay: 0.2s; }
.dot:nth-child(3) { animation-delay: 0.4s; }
@keyframes pulse {
    0%, 80%, 100% { transform: scale(0.6); opacity: 0.4; }
    40%            { transform: scale(1);   opacity: 1;   }
}

/* History item in sidebar */
.hist-item {
    padding: 0.55rem 0.8rem;
    border-radius: 8px;
    border: 1px solid #1e1e3a;
    margin-bottom: 0.4rem;
    cursor: pointer;
    transition: all 0.15s;
    font-size: 0.82rem;
    color: #9999cc !important;
    font-family: 'Space Mono', monospace;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    background: #0f0f1a;
}
.hist-item:hover { background: #1a1a2e; border-color: #3d3d7a; color: #c8c8ff !important; }

/* Buttons */
.stButton > button {
    font-family: 'Space Mono', monospace !important;
    font-size: 0.78rem !important;
    border-radius: 8px !important;
    border: 1px solid #2d2d5a !important;
    background: #12121f !important;
    color: #a78bfa !important;
    transition: all 0.2s !important;
    letter-spacing: 0.04em !important;
}
.stButton > button:hover {
    background: #1e1e3a !important;
    border-color: #a78bfa !important;
    color: #c4b5fd !important;
}

/* Text input */
.stTextArea textarea, .stTextInput input, .stSelectbox select {
    background: #0f0f1a !important;
    border: 1px solid #2d2d5a !important;
    border-radius: 10px !important;
    color: #e8e6f0 !important;
    font-family: 'Syne', sans-serif !important;
    font-size: 0.9rem !important;
}
.stTextArea textarea:focus, .stTextInput input:focus {
    border-color: #a78bfa !important;
    box-shadow: 0 0 0 2px rgba(167,139,250,0.15) !important;
}

/* Slider */
.stSlider [data-testid="stSlider"] { color: #a78bfa !important; }

/* Selectbox */
[data-testid="stSelectbox"] > div > div {
    background: #0f0f1a !important;
    border: 1px solid #2d2d5a !important;
    color: #e8e6f0 !important;
    border-radius: 8px !important;
}

/* Divider */
hr { border-color: #1e1e3a !important; }

/* Scrollbar */
::-webkit-scrollbar { width: 5px; height: 5px; }
::-webkit-scrollbar-track { background: #0a0a0f; }
::-webkit-scrollbar-thumb { background: #2d2d5a; border-radius: 4px; }
::-webkit-scrollbar-thumb:hover { background: #4a3a8a; }

/* Sidebar labels */
.sidebar-section-label {
    font-family: 'Space Mono', monospace;
    font-size: 0.65rem;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: #444466;
    margin: 1.2rem 0 0.5rem;
}

/* Model info card */
.model-card {
    background: #0f0f1a;
    border: 1px solid #1e1e3a;
    border-radius: 10px;
    padding: 0.8rem 1rem;
    font-family: 'Space Mono', monospace;
    font-size: 0.75rem;
    color: #6666aa;
    line-height: 1.8;
}
.model-card span { color: #a78bfa; }

/* Empty state */
.empty-state {
    text-align: center;
    padding: 4rem 2rem;
    color: #333355;
}
.empty-state .icon { font-size: 3.5rem; margin-bottom: 1rem; }
.empty-state h3 {
    font-family: 'Syne', sans-serif;
    font-weight: 600;
    font-size: 1.2rem;
    color: #555577;
    margin-bottom: 0.5rem;
}
.empty-state p {
    font-family: 'Space Mono', monospace;
    font-size: 0.75rem;
    color: #333355;
    line-height: 1.8;
}
</style>
""", unsafe_allow_html=True)

# ── Helpers ────────────────────────────────────────────────────────────────────
OLLAMA_BASE = "http://localhost:11434"

def get_models():
    try:
        r = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=4)
        if r.status_code == 200:
            return [m["name"] for m in r.json().get("models", [])]
    except Exception:
        pass
    return []

def is_ollama_running():
    try:
        requests.get(f"{OLLAMA_BASE}/api/tags", timeout=3)
        return True
    except Exception:
        return False

def stream_response(model, messages, temperature=0.7, max_tokens=2048):
    payload = {
        "model": model,
        "messages": messages,
        "stream": True,
        "options": {"temperature": temperature, "num_predict": max_tokens},
    }
    with requests.post(f"{OLLAMA_BASE}/api/chat", json=payload, stream=True, timeout=120) as r:
        for line in r.iter_lines():
            if line:
                chunk = json.loads(line)
                if chunk.get("message", {}).get("content"):
                    yield chunk["message"]["content"]
                if chunk.get("done"):
                    break

def fmt_time(ts): return datetime.fromtimestamp(ts).strftime("%H:%M")

# ── Session state ──────────────────────────────────────────────────────────────
if "conversations" not in st.session_state:
    st.session_state.conversations = {}          # id -> {title, messages, ts}
if "active_conv" not in st.session_state:
    st.session_state.active_conv = None
if "generating" not in st.session_state:
    st.session_state.generating = False

def new_conversation():
    cid = str(time.time())
    st.session_state.conversations[cid] = {"title": "New chat", "messages": [], "ts": time.time()}
    st.session_state.active_conv = cid
    return cid

def active_msgs():
    cid = st.session_state.active_conv
    if cid and cid in st.session_state.conversations:
        return st.session_state.conversations[cid]["messages"]
    return []

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown('<div class="app-header"><h1>🧠 Ollama</h1><p>Local LLM Interface</p></div>', unsafe_allow_html=True)

    # Connection status
    online = is_ollama_running()
    if online:
        st.markdown('<div class="status-badge status-online">● CONNECTED · localhost:11434</div>', unsafe_allow_html=True)
    else:
        st.markdown('<div class="status-badge status-offline">✕ OFFLINE · start ollama serve</div>', unsafe_allow_html=True)

    # Model picker
    st.markdown('<div class="sidebar-section-label">Model</div>', unsafe_allow_html=True)
    models = get_models()
    if models:
        selected_model = st.selectbox("", models, label_visibility="collapsed")
    else:
        selected_model = st.text_input("Model name", value="llama3", placeholder="e.g. llama3, mistral…", label_visibility="collapsed")

    # Parameters
    st.markdown('<div class="sidebar-section-label">Parameters</div>', unsafe_allow_html=True)
    temperature = st.slider("Temperature", 0.0, 2.0, 0.7, 0.05)
    max_tokens  = st.slider("Max tokens",  64,  4096, 1024, 64)

    system_prompt = st.text_area(
        "System prompt",
        value="You are a helpful, concise, and thoughtful AI assistant.",
        height=90,
        label_visibility="collapsed",
        placeholder="System prompt…",
    )

    # Model info card
    if selected_model and online:
        st.markdown(f"""
        <div class="model-card">
            model&nbsp;&nbsp;&nbsp;<span>{selected_model}</span><br>
            temp&nbsp;&nbsp;&nbsp;&nbsp;<span>{temperature}</span><br>
            max_tok&nbsp;<span>{max_tokens}</span>
        </div>
        """, unsafe_allow_html=True)

    st.markdown('<div class="sidebar-section-label">Conversations</div>', unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    with col1:
        if st.button("＋ New", use_container_width=True):
            new_conversation()
            st.rerun()
    with col2:
        if st.button("↺ Reset", use_container_width=True):
            if st.session_state.active_conv:
                cid = st.session_state.active_conv
                st.session_state.conversations[cid]["messages"] = []
                st.rerun()

    # History list
    sorted_convs = sorted(st.session_state.conversations.items(), key=lambda x: x[1]["ts"], reverse=True)
    for cid, conv in sorted_convs:
        label = conv["title"][:34] + "…" if len(conv["title"]) > 34 else conv["title"]
        active_marker = "▸ " if cid == st.session_state.active_conv else "  "
        st.markdown(f'<div class="hist-item">{active_marker}{label}</div>', unsafe_allow_html=True)
        if st.button(label, key=f"conv_{cid}", use_container_width=True, help=conv["title"]):
            st.session_state.active_conv = cid
            st.rerun()

# ── Main area ──────────────────────────────────────────────────────────────────
# Ensure we always have an active conversation
if st.session_state.active_conv is None or st.session_state.active_conv not in st.session_state.conversations:
    new_conversation()

msgs = active_msgs()

# ── Render chat messages ────────────────────────────────────────────────────────
chat_placeholder = st.container()

with chat_placeholder:
    if not msgs:
        st.markdown("""
        <div class="empty-state">
            <div class="icon">✦</div>
            <h3>Start a conversation</h3>
            <p>Type a message below to begin.<br>
            Make sure Ollama is running and a model is selected.</p>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown('<div class="chat-container">', unsafe_allow_html=True)
        for msg in msgs:
            role = msg["role"]
            content = msg["content"]
            ts = fmt_time(msg.get("ts", time.time()))

            if role == "user":
                st.markdown(f"""
                <div class="message-row user">
                    <div class="avatar avatar-user">👤</div>
                    <div>
                        <div class="bubble bubble-user">{content}</div>
                        <div class="msg-time right">{ts}</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
            elif role == "assistant":
                st.markdown(f"""
                <div class="message-row">
                    <div class="avatar avatar-ai">🧠</div>
                    <div>
                        <div class="bubble bubble-ai">{content}</div>
                        <div class="msg-time">{ts}</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

# ── Input area ─────────────────────────────────────────────────────────────────
st.markdown("---")

with st.form("chat_form", clear_on_submit=True):
    col_input, col_btn = st.columns([6, 1])
    with col_input:
        user_input = st.text_area(
            "Message",
            height=80,
            placeholder="Ask anything… (Shift+Enter for new line)",
            label_visibility="collapsed",
        )
    with col_btn:
        st.markdown("<br>", unsafe_allow_html=True)
        submit = st.form_submit_button("Send ➤", use_container_width=True)

if submit and user_input.strip():
    if not online:
        st.error("⚠️ Ollama is not running. Please start it with `ollama serve`.")
    elif not selected_model:
        st.warning("Please select or enter a model name.")
    else:
        cid = st.session_state.active_conv
        conv = st.session_state.conversations[cid]

        # Add user message
        conv["messages"].append({"role": "user", "content": user_input.strip(), "ts": time.time()})

        # Update title from first user message
        if conv["title"] == "New chat":
            conv["title"] = user_input.strip()[:48]

        # Build API messages (include system prompt)
        api_msgs = [{"role": "system", "content": system_prompt}] + [
            {"role": m["role"], "content": m["content"]}
            for m in conv["messages"]
        ]

        # Stream response
        with st.spinner(""):
            st.markdown("""
            <div class="message-row">
                <div class="avatar avatar-ai">🧠</div>
                <div class="thinking">
                    <div class="dot"></div><div class="dot"></div><div class="dot"></div>
                    thinking…
                </div>
            </div>
            """, unsafe_allow_html=True)

            response_placeholder = st.empty()
            full_response = ""
            try:
                for chunk in stream_response(selected_model, api_msgs, temperature, max_tokens):
                    full_response += chunk
                    response_placeholder.markdown(f"""
                    <div class="message-row">
                        <div class="avatar avatar-ai">🧠</div>
                        <div class="bubble bubble-ai">{full_response}▌</div>
                    </div>
                    """, unsafe_allow_html=True)

                conv["messages"].append({"role": "assistant", "content": full_response, "ts": time.time()})
                response_placeholder.empty()

            except Exception as e:
                st.error(f"Error communicating with Ollama: {e}")

        st.rerun()

# ── Footer ─────────────────────────────────────────────────────────────────────
st.markdown("""
<div style="text-align:center; padding: 1.5rem 0 0.5rem; font-family:'Space Mono',monospace;
            font-size:0.65rem; color:#333355; letter-spacing:0.08em;">
    OLLAMA CHAT · RUNNING LOCALLY · NO DATA LEAVES YOUR MACHINE
</div>
""", unsafe_allow_html=True)
